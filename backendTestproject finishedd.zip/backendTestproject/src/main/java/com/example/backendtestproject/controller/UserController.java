package com.example.backendtestproject.controller;


import com.example.backendtestproject.repository.UserRepository;
import com.example.backendtestproject.model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@CrossOrigin("http://localhost:5173")
public class UserController {

@Autowired

private UserRepository userRepository;

@PostMapping("/user")  //14:30
    User newUser(@RequestBody User newUser){
    return userRepository.save(newUser);
}


@GetMapping("/users")
List<User> getAllUsers(){
    return userRepository.findAll();

}


    @DeleteMapping("/user/{id}")
    public void deleteUser(@PathVariable Integer id) {
        // Implement logic to delete user with the specified ID from the database
        userRepository.deleteById(id);
    }



    //
//    @PostMapping("/login")
//    public boolean loginUser(@RequestBody User loginUser) {
//        // Retrieve the user from the database based on the provided username
//        User existingUser = userRepository.findByUserId(loginUser.getUserId());
//        if (existingUser != null) {
//            // Check if the password matches
//            if (existingUser.getUserPassword().equals(loginUser.getUserPassword())) {
//                // Passwords match, login successful
//                return true;
//            }
//        }
//        // Login failed
//        return false;
//    }
    //



}
