//package com.example.backendtestproject.repository;
//
//import com.example.backendtestproject.model.UserApps;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface UserAppsRepository extends JpaRepository<UserApps, Integer> {
//}
